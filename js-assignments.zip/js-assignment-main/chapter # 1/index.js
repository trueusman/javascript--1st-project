alert(" Error! Please enter a valid password.");

alert(" Welcome to JS Land...\nHappy Coding!");

alert(" Welcome to JS Land...");


alert(" Happy Coding...\n prevent this page form creating additional dailogs")

alert("Hello... I can run JS through my web browser's console")
