
let age = 17;
alert("I am " + age + " years old");

let visitCount = "4 Time";

alert("You have visited this page " + visitCount )

let dob = 2005;

document.write("My birth year is " + dob + "<br>");
document.write("Data type of my declared variable is " + typeof dob);
document.write("<br><br>");

let visitorName = "Asad Ullah";
let productTitle = "T-shirt";
let quantity = 6;
document.write("<b>" + visitorName + "</b> ordered <b>" + quantity + " " + productTitle + "(s)</b>    <a href='https://www.daraz.pk/#?'>Online Link</a>");

