
let username;

let myName = "Asad Ullah";


let message = "Hello World";
alert(message);


let studentName = "Asad Ullah";
let studentAge = "20 years old";
let studentCourse = "Certified Web & App Development";
alert(studentName);
alert(studentAge);
alert(studentCourse);


let pizza = "PIZZA\nPIZZ\nPIZ\nPI\nP";
alert(pizza);


let email = "asad@example.com";
alert("My email address is " + email);


let book = "A smarter way to learn JavaScript";
alert("I am trying to learn from the Book " + book);


document.write("Yah! I can write HTML content through JavaScript<br>");

// 9. Store this string and show in alert and browser
let design = "▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
alert(design);

